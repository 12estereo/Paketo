package com.a13j0.world

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.WindowManager
import android.view.inputmethod.EditorInfo
import android.webkit.*
import android.widget.*
import org.mozilla.geckoview.GeckoRuntime
import org.mozilla.geckoview.GeckoSession
import org.mozilla.geckoview.GeckoView

class MainActivity : Activity() {
    private lateinit var runtime: GeckoRuntime
    private lateinit var session: GeckoSession
    private lateinit var geckoView: GeckoView
    private lateinit var address: EditText
    private lateinit var status: TextView
    private var flashWeb: WebView? = null
    private var flashMode = false
    private val green = Color.rgb(57, 255, 120)
    private val bg = Color.rgb(5, 9, 7)
    private val panel = Color.rgb(16, 29, 20)
    private val prefs by lazy { getSharedPreferences("a13j0", MODE_PRIVATE) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE)
        runtime = GeckoRuntime.create(this)
        session = GeckoSession()
        session.open(runtime)
        buildUi()
        geckoView.setSession(session)
        loadUrl("https://www.google.com")
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(bg) }
        val brand = TextView(this).apply {
            text = "++A13J0++ WORLD"; setTextColor(green); textSize = 20f
            gravity = Gravity.CENTER; setPadding(8, 12, 8, 8); typeface = android.graphics.Typeface.DEFAULT_BOLD
        }
        root.addView(brand, LinearLayout.LayoutParams(-1, -2))
        val bar = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; setPadding(8, 4, 8, 8); gravity = Gravity.CENTER_VERTICAL }
        address = EditText(this).apply {
            hint = "Buscar o escribir una dirección"; setSingleLine(true); imeOptions = EditorInfo.IME_ACTION_GO
            setTextColor(Color.WHITE); setHintTextColor(Color.LTGRAY); setBackgroundColor(panel); textSize = 14f; setPadding(12, 8, 12, 8)
            setOnEditorActionListener { _, action, _ -> if (action == EditorInfo.IME_ACTION_GO || action == EditorInfo.IME_ACTION_DONE) { navigateCurrent(); true } else false }
        }
        bar.addView(address, LinearLayout.LayoutParams(0, 48, 1f))
        bar.addView(makeButton("IR") { navigateCurrent() })
        root.addView(bar)
        val controls = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER; setPadding(3, 0, 3, 6) }
        controls.addView(makeButton("‹") { if (flashMode) flashWeb?.goBack() else if (session.canGoBack()) session.goBack() })
        controls.addView(makeButton("›") { if (!flashMode && session.canGoForward()) session.goForward() })
        controls.addView(makeButton("↻") { if (flashMode) flashWeb?.reload() else session.reload() })
        controls.addView(makeButton("FLASH") { if (flashMode) showNormalBrowser() else showFlashPrompt() })
        controls.addView(makeButton("☰") { showMenu() })
        root.addView(controls)
        geckoView = GeckoView(this)
        root.addView(geckoView, LinearLayout.LayoutParams(-1, 0, 1f))
        status = TextView(this).apply { text = "NAVEGADOR FIREFOX · PRIVACIDAD"; setTextColor(green); textSize = 10f; gravity = Gravity.CENTER; setPadding(4, 5, 4, 5) }
        root.addView(status)
        setContentView(root)
    }

    private fun makeButton(label: String, action: () -> Unit): Button = Button(this).apply {
        text = label; setTextColor(green); textSize = 11f; isAllCaps = false; setPadding(5, 0, 5, 0)
        setBackgroundColor(panel); setOnClickListener { action() }
    }

    private fun normalize(raw: String): String {
        val value = raw.trim()
        if (value.isEmpty()) return ""
        if (value.startsWith("http://") || value.startsWith("https://")) return value
        return if (value.contains('.') && !value.contains(' ')) "https://$value" else "https://www.google.com/search?q=" + Uri.encode(value)
    }

    private fun navigateCurrent() {
        val url = normalize(address.text.toString())
        if (url.isEmpty()) return
        address.setText(url)
        if (flashMode) loadFlashPage(url) else session.loadUri(url)
        saveHistory(url)
    }

    private fun loadUrl(url: String) { address.setText(url); session.loadUri(url); saveHistory(url) }
    private fun saveHistory(url: String) {
        val list = (prefs.getStringSet("history", emptySet()) ?: emptySet()).toMutableSet()
        list.add(url); while (list.size > 150) list.remove(list.first())
        prefs.edit().putStringSet("history", list).apply()
    }

    private fun showFlashPrompt() {
        val input = EditText(this).apply { hint = "https://sitio-con-juegos-flash.com"; setSingleLine(true); setTextColor(Color.WHITE) }
        AlertDialog.Builder(this).setTitle("FLASH WORLD")
            .setMessage("Abre una página con contenido Flash o pega la dirección de un archivo .swf. Ruffle se carga desde Internet; no es Adobe Flash Player original y algunos chats, cámaras o juegos pueden no funcionar.")
            .setView(input).setPositiveButton("ABRIR FLASH") { _, _ ->
                val url = normalize(input.text.toString()); if (url.isNotEmpty()) { showFlashBrowser(); loadFlashPage(url) }
            }.setNegativeButton("Cancelar", null).show()
    }

    private fun showFlashBrowser() {
        flashMode = true
        geckoView.visibility = android.view.View.GONE
        flashWeb?.destroy()
        val web = WebView(this)
        flashWeb = web
        web.setBackgroundColor(Color.BLACK)
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.settings.loadsImagesAutomatically = true
        web.settings.mediaPlaybackRequiresUserGesture = false
        web.settings.allowFileAccess = false
        web.settings.allowContentAccess = false
        web.settings.mixedContentMode = WebSettings.MIXED_CONTENT_NEVER_ALLOW
        web.webViewClient = object : WebViewClient() {
            override fun onPageFinished(view: WebView, url: String) {
                status.text = "FLASH WORLD · RUFFLE WEB · CONEXIÓN A INTERNET REQUERIDA"
                // Inject Ruffle into legacy pages that expose Flash embeds.
                val js = "(function(){if(window.__a13j0RuffleInjected)return;window.__a13j0RuffleInjected=true;window.RufflePlayer=window.RufflePlayer||{};window.RufflePlayer.config={autoplay:'on',unmuteOverlay:'visible',letterbox:'fullscreen',warnOnUnsupportedContent:false};var s=document.createElement('script');s.src='https://unpkg.com/@ruffle-rs/ruffle';document.head.appendChild(s);})();"
                view.evaluateJavascript(js, null)
            }
        }
        web.webChromeClient = object : WebChromeClient() {
            override fun onPermissionRequest(request: PermissionRequest) {
                // Ruffle does not implement Flash webcam/microphone APIs. Do not silently grant site permissions.
                request.deny()
                runOnUiThread { Toast.makeText(this@MainActivity, "La cámara y el micrófono Flash no están disponibles en este modo", Toast.LENGTH_LONG).show() }
            }
        }
        val parent = geckoView.parent as? LinearLayout
        parent?.addView(web, parent.indexOfChild(geckoView), LinearLayout.LayoutParams(-1, 0, 1f))
        status.text = "FLASH WORLD · PREPARANDO REPRODUCTOR"
    }

    private fun loadFlashPage(url: String) {
        if (!flashMode) showFlashBrowser()
        address.setText(url)
        if (url.substringBefore('?').substringBefore('#').endsWith(".swf", ignoreCase = true)) {
            val html = "<!doctype html><html><head><meta name='viewport' content='width=device-width,initial-scale=1'><style>html,body{margin:0;background:#050907;color:#39ff78;width:100%;height:100%;overflow:hidden}#player{width:100vw;height:100vh}</style><script>window.RufflePlayer=window.RufflePlayer||{};window.RufflePlayer.config={autoplay:'on',unmuteOverlay:'visible',letterbox:'fullscreen'};</script><script src='https://unpkg.com/@ruffle-rs/ruffle'></script></head><body><div id='player'></div><script>window.addEventListener('load',function(){try{var p=window.RufflePlayer.newest().createPlayer();p.style.width='100%';p.style.height='100%';document.getElementById('player').appendChild(p);p.load(" + org.json.JSONObject.quote(url) + ");}catch(e){document.body.innerHTML='No se pudo iniciar Ruffle: '+e;}});</script></body></html>"
            flashWeb?.loadDataWithBaseURL(url.substringBeforeLast('/') + '/', html, "text/html", "UTF-8", null)
        } else flashWeb?.loadUrl(url)
        saveHistory(url)
    }

    private fun showNormalBrowser() {
        flashMode = false
        flashWeb?.let { (it.parent as? LinearLayout)?.removeView(it); it.stopLoading(); it.destroy() }
        flashWeb = null
        geckoView.visibility = android.view.View.VISIBLE
        status.text = "NAVEGADOR FIREFOX · PRIVACIDAD"
        address.setText("https://www.google.com")
        session.loadUri("https://www.google.com")
    }

    private fun showMenu() {
        val items = arrayOf("Marcadores", "Guardar página actual", "Historial", "Privacidad y DNS", "VPN (integración futura)", "Acerca de")
        AlertDialog.Builder(this).setTitle("++A13J0++ WORLD").setItems(items) { _, which ->
            when (which) {
                0 -> showBookmarks()
                1 -> { val set = (prefs.getStringSet("bookmarks", emptySet()) ?: emptySet()).toMutableSet(); set.add(address.text.toString()); prefs.edit().putStringSet("bookmarks", set).apply(); Toast.makeText(this, "Marcador guardado", Toast.LENGTH_SHORT).show() }
                2 -> showHistory()
                3 -> showPrivacy()
                4 -> AlertDialog.Builder(this).setMessage("La aplicación no incluye un servicio VPN activo. Puedes usar una VPN instalada en Android; la integración con un proveedor requerirá sus credenciales y servicio compatibles.").setPositiveButton("Entendido", null).show()
                5 -> AlertDialog.Builder(this).setMessage("Navegador independiente basado en GeckoView de Mozilla. Flash World utiliza Ruffle Web desde Internet, no Adobe Flash Player original. Versión 1.1.0.").setPositiveButton("Cerrar", null).show()
            }
        }.show()
    }

    private fun showBookmarks() {
        val marks = prefs.getStringSet("bookmarks", emptySet())?.toList() ?: emptyList()
        AlertDialog.Builder(this).setTitle("Marcadores").setItems(marks.toTypedArray()) { _, i -> if (i < marks.size) { if (flashMode) loadFlashPage(marks[i]) else loadUrl(marks[i]) } }.setNegativeButton("Cerrar", null).show()
    }
    private fun showHistory() {
        val items = (prefs.getStringSet("history", emptySet())?.toList() ?: emptyList()).reversed()
        AlertDialog.Builder(this).setTitle("Historial").setItems(items.toTypedArray()) { _, i -> if (flashMode) loadFlashPage(items[i]) else loadUrl(items[i]) }
            .setNeutralButton("Borrar historial") { _, _ -> prefs.edit().remove("history").apply() }.setNegativeButton("Cerrar", null).show()
    }
    private fun showPrivacy() {
        val options = arrayOf("Abrir ajustes de DNS privado", "Cloudflare DNS: 1dot1dot1dot1.cloudflare-dns.com", "Google DNS: dns.google", "Quad9 DNS: dns.quad9.net", "Permisos de cámara y micrófono")
        AlertDialog.Builder(this).setTitle("Privacidad y seguridad").setItems(options) { _, i ->
            if (i == 0) openPrivateDnsSettings() else if (i in 1..3) {
                val host = options[i].substringAfter(": ")
                AlertDialog.Builder(this).setMessage("Host DNS privado: $host\n\nAndroid configura DNS privado a nivel del sistema. Esta aplicación no cambia el DNS automáticamente.")
                    .setPositiveButton("Abrir ajustes") { _, _ -> openPrivateDnsSettings() }.setNegativeButton("Cerrar", null).show()
            } else AlertDialog.Builder(this).setMessage("Los permisos se solicitan por sitio cuando el motor del navegador los admite. En Flash World, Ruffle no ofrece cámara ni micrófono Flash. Evita conceder permisos a sitios desconocidos.").setPositiveButton("Entendido", null).show()
        }.setNegativeButton("Cerrar", null).show()
    }
    private fun openPrivateDnsSettings() { try { startActivity(Intent(Settings.ACTION_PRIVATE_DNS_SETTINGS)) } catch (_: Exception) { startActivity(Intent(Settings.ACTION_SETTINGS)) } }

    override fun onBackPressed() {
        if (flashMode && flashWeb?.canGoBack() == true) flashWeb?.goBack()
        else if (!flashMode && session.canGoBack()) session.goBack()
        else if (flashMode) showNormalBrowser() else super.onBackPressed()
    }
    override fun onDestroy() { flashWeb?.destroy(); if (::session.isInitialized) session.close(); super.onDestroy() }
}
