# ++A13J0++ WORLD 1.1.0

Android browser project based on Mozilla GeckoView (ARM64).

## Included
- Separate normal browsing mode using GeckoView.
- Flash World mode using Ruffle Web injected into legacy pages and a direct `.swf` player wrapper.
- Bookmarks and local browsing history.
- Android Private DNS settings shortcut and provider hostname guidance (Cloudflare, Google, Quad9).
- A clearly labeled future VPN integration point; no VPN service/provider is bundled.
- Flash mode denies camera/microphone permission requests because Ruffle does not implement the original Flash webcam/microphone APIs.

## Flash compatibility notice
This does **not** include Adobe's original Flash Player plugin. Ruffle is an open-source Flash-compatible emulator loaded from its public CDN, so Flash mode requires internet access to fetch Ruffle. Compatibility varies by game and website. Complex Flash chat systems, RTMP/NetConnection services, webcam and microphone features may not work. This build has not been device-tested against every legacy site.

## Security status
GeckoView is used for normal browsing. The app does not claim a complete ad/tracker blocker, guaranteed WebRTC IP-leak protection, or a built-in VPN. Android Private DNS must be configured by the user in system settings. Use a separate trusted VPN app if needed.

## Build
Use the supplied GitHub Actions workflow. The dependency is the ARM64 GeckoView artifact; intended for 64-bit ARM Android devices.
