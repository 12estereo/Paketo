# OMNI MATRIX

Aplicación Android en español para explorar directorios públicos de cámaras web del mundo. Identidad visual inspirada en ciencia ficción digital: negro profundo, verde Matrix y un ojo global.

## Funciones de esta versión
- Buscador de lugares para encontrar webcams públicas.
- Accesos por categorías: ciudades, playas, parques, animales, montañas y puertos.
- Directorios de cámaras: Overlook Cams, WorldCam.tv, EarthCam, SkylineWebcams, Live Public Webcams y SeeDive.
- Navegación integrada con botón Volver.
- Icono y nombre OMNI MATRIX.

La app no captura ni retransmite cámaras: abre páginas de operadores y directorios públicos. La disponibilidad depende de cada proveedor.

## Compilar
Requiere JDK 17, Android SDK 35 y Gradle 8.9.

```bash
gradle assembleDebug
```

APK: `app/build/outputs/apk/debug/app-debug.apk`.
