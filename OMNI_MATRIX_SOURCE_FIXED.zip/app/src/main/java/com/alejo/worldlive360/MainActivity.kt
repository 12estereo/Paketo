package com.alejo.omnimatrix360

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.graphics.Typeface
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.webkit.WebChromeClient
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.*
import android.content.Context
import android.content.SharedPreferences
import android.graphics.drawable.GradientDrawable
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.net.Uri

class MainActivity : Activity() {
    private val bg = Color.rgb(3, 8, 6)
    private val panel = Color.rgb(12, 25, 18)
    private val mint = Color.rgb(57, 255, 120)
    private val white = Color.WHITE
    private lateinit var root: LinearLayout
    private lateinit var prefs: SharedPreferences
    private var web: WebView? = null
    private var currentTitle = "OMNI MATRIX"

    data class CamSource(val title: String, val subtitle: String, val url: String, val emoji: String)
    private val sources = listOf(
        CamSource("Overlook Cams", "Miles de cámaras: ciudades, playas y naturaleza", "https://overlookcams.com/", "🌍"),
        CamSource("WorldCam.tv", "Cámaras en vivo de más de 90 países", "https://worldcam.tv/", "🗺️"),
        CamSource("EarthCam", "Lugares emblemáticos y ciudades", "https://www.earthcam.com/", "🏙️"),
        CamSource("SkylineWebcams", "Plazas, playas, montañas y destinos", "https://www.skylinewebcams.com/", "🌆"),
        CamSource("Live Public Webcams", "Transmisiones públicas verificadas", "https://livepublicwebcams.com/", "📡"),
        CamSource("SeeDive", "Explora cámaras públicas en un mapa", "https://seedive.org/seedive/", "📍")
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = getSharedPreferences("omnimatrix", Context.MODE_PRIVATE)
        showHome()
    }

    private fun shape(color: Int, radius: Float): GradientDrawable = GradientDrawable().apply {
        setColor(color); cornerRadius = radius
    }

    private fun text(value: String, size: Float, color: Int = white, bold: Boolean = false): TextView = TextView(this).apply {
        this.text = value; textSize = size; setTextColor(color)
        if (bold) typeface = Typeface.DEFAULT_BOLD
    }

    private fun base(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setBackgroundColor(bg)
        setPadding(dp(18), dp(14), dp(18), dp(18))
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun showHome() {
        web?.destroy(); web = null
        root = base()
        val scroll = ScrollView(this)
        val content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val header = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(0, dp(8), 0, dp(16)) }
        header.addView(text("🌎  OMNI MATRIX", 25f, mint, true))
        header.addView(text("EL MUNDO ENTERO ANTE TUS OJOS", 11f, Color.LTGRAY, true).apply { setPadding(0, dp(6), 0, 0) })
        content.addView(header)

        val searchRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val search = EditText(this).apply {
            hint = "Busca una ciudad, país o lugar…"; setHintTextColor(Color.LTGRAY); setTextColor(white)
            textSize = 14f; singleLine = true; imeOptions = EditorInfo.IME_ACTION_SEARCH
            background = shape(panel, dp(14).toFloat()); setPadding(dp(14), 0, dp(10), 0)
            layoutParams = LinearLayout.LayoutParams(0, dp(50), 1f)
        }
        val go = Button(this).apply { text = "VER"; setTextColor(bg); background = shape(mint, dp(14).toFloat()); setOnClickListener { searchFor(search.text.toString()) } }
        search.setOnEditorActionListener { _, action, _ -> if (action == EditorInfo.IME_ACTION_SEARCH) { searchFor(search.text.toString()); true } else false }
        searchRow.addView(search); searchRow.addView(go, LinearLayout.LayoutParams(dp(72), dp(50)).apply { leftMargin = dp(8) })
        content.addView(searchRow)

        val hero = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(dp(18), dp(20), dp(18), dp(20)); background = shape(Color.rgb(15, 57, 67), dp(18).toFloat())
        }
        hero.addView(text("UN PORTAL A TODO EL PLANETA", 21f, white, true))
        hero.addView(text("Explora ciudades, playas, parques, montañas y rincones sorprendentes mediante cámaras web públicas.", 13f, Color.rgb(220, 240, 240)).apply { setPadding(0, dp(8), 0, dp(12)) })
        hero.addView(text("🔴  INICIAR EXPLORACIÓN GLOBAL", 12f, mint, true))
        content.addView(hero, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(16) })

        content.addView(sectionTitle("EXPLORA POR CATEGORÍA"))
        val categories = listOf(
            listOf("🏙️  Ciudades", "city live webcam"), listOf("🏖️  Playas", "beach live webcam"),
            listOf("🌳  Parques y naturaleza", "national park nature live webcam"), listOf("🐘  Animales", "wildlife live webcam"),
            listOf("🏔️  Montañas", "mountain live webcam"), listOf("🚢  Puertos y costas", "harbor port live webcam")
        )
        val grid = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        for (i in categories.indices step 2) {
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            for (j in i until minOf(i + 2, categories.size)) {
                val item = categories[j]
                val b = TextView(this).apply {
                    text = item[0]; textSize = 14f; typeface = Typeface.DEFAULT_BOLD; setTextColor(white)
                    gravity = Gravity.CENTER_VERTICAL; setPadding(dp(12), dp(14), dp(8), dp(14)); background = shape(panel, dp(14).toFloat())
                    setOnClickListener { searchFor(item[1]) }
                }
                row.addView(b, LinearLayout.LayoutParams(0, dp(66), 1f).apply { if (j == i) rightMargin = dp(7) else leftMargin = dp(7) })
            }
            grid.addView(row, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(8) })
        }
        content.addView(grid)
        content.addView(sectionTitle("NODOS DE TRANSMISIÓN PÚBLICA"))
        sources.forEach { src ->
            val card = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL; setPadding(dp(15), dp(13), dp(15), dp(13)); background = shape(panel, dp(14).toFloat())
                setOnClickListener { openUrl(src.url, src.title) }
            }
            val top = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
            top.addView(text(src.emoji, 25f))
            val labels = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(12), 0, 0, 0) }
            labels.addView(text(src.title, 16f, white, true)); labels.addView(text(src.subtitle, 12f, Color.LTGRAY).apply { setPadding(0, dp(3), 0, 0) })
            top.addView(labels, LinearLayout.LayoutParams(0, -2, 1f))
            top.addView(text("ABRIR  ›", 11f, mint, true))
            card.addView(top)
            content.addView(card, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(9) })
        }
        content.addView(text("Las cámaras pertenecen a sus operadores. La disponibilidad y el directo dependen de cada emisor.", 11f, Color.GRAY).apply { setPadding(dp(4), dp(18), dp(4), dp(8)) })
        scroll.addView(content); root.addView(scroll); setContentView(root)
    }

    private fun sectionTitle(s: String) = text(s, 13f, mint, true).apply { setPadding(0, dp(22), 0, dp(4)) }

    private fun searchFor(q: String) {
        if (q.isBlank()) { Toast.makeText(this, "Escribe un lugar para buscar", Toast.LENGTH_SHORT).show(); return }
        val url = "https://www.google.com/search?q=" + Uri.encode("$q live webcam en vivo")
        openUrl(url, "Buscar: $q")
    }

    private fun openUrl(url: String, title: String) {
        currentTitle = title
        root = base()
        val bar = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(0, 0, 0, dp(10)) }
        val back = Button(this).apply { text = "‹ VOLVER"; setTextColor(mint); background = shape(panel, dp(12).toFloat()); setOnClickListener { showHome() } }
        bar.addView(back)
        bar.addView(text(title, 15f, white, true).apply { setPadding(dp(12), 0, 0, 0) }, LinearLayout.LayoutParams(0, -2, 1f))
        root.addView(bar)
        val browser = WebView(this).apply {
            setBackgroundColor(Color.WHITE)
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            settings.loadsImagesAutomatically = true
            settings.mixedContentMode = WebSettings.MIXED_CONTENT_NEVER_ALLOW
            settings.mediaPlaybackRequiresUserGesture = true
            webViewClient = WebViewClient()
            webChromeClient = WebChromeClient()
            loadUrl(url)
        }
        web = browser
        root.addView(browser, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
    }

    override fun onBackPressed() {
        val current = web
        if (current != null && current.canGoBack()) current.goBack() else showHome()
    }

    override fun onDestroy() { web?.destroy(); super.onDestroy() }
}
