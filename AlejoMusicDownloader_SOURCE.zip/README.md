# Alejo Music Downloader

Android starter project with an Alejo Music splash screen and direct-file downloading through Android DownloadManager.

## Current version
- Downloads direct HTTP/HTTPS file links that the user is authorized to download.
- Saves files under Downloads/AlejoMusic.
- Does not extract audio from video, convert formats, download protected streams, or process playlists yet. Those features require a lawful source/provider integration and dedicated media-processing implementation.
- Selecting MP3/MP4 only accepts a direct URL whose file extension matches; it does not re-encode media or create 320 kbps audio.

## Build
Use the included GitHub Actions workflow `.github/workflows/build-apk.yml` to build a debug APK with Java 17, Android SDK 35 and Gradle 8.9.
