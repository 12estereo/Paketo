package com.alejo.musicdownloader

import android.app.Activity
import android.app.DownloadManager
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.view.Gravity
import android.view.View
import android.view.inputmethod.InputMethodManager
import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.widget.*
import android.graphics.drawable.GradientDrawable

class MainActivity : Activity() {
    private val bg = Color.rgb(15, 15, 27)
    private val panel = Color.rgb(29, 27, 48)
    private val purple = Color.rgb(151, 91, 255)
    private lateinit var urlInput: EditText
    private lateinit var status: TextView
    private lateinit var format: Spinner

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = bg
        window.navigationBarColor = bg
        showLoader()
    }

    private fun showLoader() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setBackgroundColor(bg)
            setPadding(28, 28, 28, 28)
        }
        val logo = TextView(this).apply {
            text = "♫"
            textSize = 76f
            setTextColor(purple)
            gravity = Gravity.CENTER
        }
        val name = TextView(this).apply {
            text = "ALEJO MUSIC"
            textSize = 27f
            letterSpacing = .12f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
        }
        val sub = TextView(this).apply {
            text = "DOWNLOADER"
            textSize = 13f
            letterSpacing = .28f
            setTextColor(Color.LTGRAY)
            gravity = Gravity.CENTER
        }
        root.addView(logo)
        root.addView(name)
        root.addView(sub)
        setContentView(root)
        root.postDelayed({ showMain() }, 1200)
    }

    private fun showMain() {
        val scroll = ScrollView(this)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(20, 22, 20, 28)
            setBackgroundColor(bg)
        }
        scroll.addView(root)

        val brand = TextView(this).apply {
            text = "♫  ALEJO MUSIC"
            textSize = 23f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(Color.WHITE)
        }
        root.addView(brand)
        root.addView(label("Descarga y organiza tus archivos multimedia"))

        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(18, 18, 18, 18)
            background = rounded(panel, 22)
        }
        val heading = label("DESCARGAR ARCHIVO").apply {
            textSize = 16f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(Color.WHITE)
        }
        card.addView(heading)
        urlInput = EditText(this).apply {
            hint = "Pega un enlace directo autorizado..."
            setHintTextColor(Color.LTGRAY)
            setTextColor(Color.WHITE)
            textSize = 14f
            setSingleLine(true)
            background = rounded(Color.rgb(43, 40, 65), 12)
            setPadding(14, 12, 14, 12)
        }
        val inputParams = LinearLayout.LayoutParams(-1, -2)
        inputParams.topMargin = dp(14)
        card.addView(urlInput, inputParams)

        card.addView(label("Formato del archivo").apply { setTextColor(Color.LTGRAY) })
        format = Spinner(this)
        val formats = arrayOf("Conservar formato original", "MP3 (requiere archivo MP3 directo)", "MP4 (requiere archivo MP4 directo)")
        format.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, formats)
        card.addView(format)

        val download = Button(this).apply {
            text = "DESCARGAR"
            isAllCaps = false
            setTextColor(Color.WHITE)
            background = rounded(purple, 14)
            setOnClickListener { startDownload() }
        }
        val btnParams = LinearLayout.LayoutParams(-1, dp(52))
        btnParams.topMargin = dp(16)
        card.addView(download, btnParams)
        root.addView(card)

        val info = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(18, 16, 18, 16)
            background = rounded(panel, 22)
        }
        val infoTitle = label("HERRAMIENTAS").apply {
            textSize = 16f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(Color.WHITE)
        }
        info.addView(infoTitle)
        info.addView(label("• Descarga de enlaces directos\n• Archivos guardados en Descargas/AlejoMusic\n• Interfaz preparada para futuras funciones de listas y conversión"))
        val infoParams = LinearLayout.LayoutParams(-1, -2)
        infoParams.topMargin = dp(16)
        root.addView(info, infoParams)

        status = label("Usa enlaces directos de archivos que tengas permiso para descargar.")
        status.setTextColor(Color.rgb(190, 177, 220))
        val statusParams = LinearLayout.LayoutParams(-1, -2)
        statusParams.topMargin = dp(14)
        root.addView(status, statusParams)
        setContentView(scroll)
    }

    private fun startDownload() {
        val raw = urlInput.text.toString().trim()
        if (raw.isEmpty()) {
            status.text = "Pega primero un enlace."
            return
        }
        val uri = try { Uri.parse(raw) } catch (e: Exception) { null }
        if (uri == null || (uri.scheme != "https" && uri.scheme != "http") || uri.host.isNullOrBlank()) {
            status.text = "El enlace no parece válido. Usa una dirección HTTP o HTTPS directa."
            return
        }
        val choice = format.selectedItemPosition
        val path = uri.lastPathSegment?.takeIf { it.contains(".") } ?: "archivo_descargado"
        val mime = when (choice) {
            1 -> if (path.endsWith(".mp3", true)) "audio/mpeg" else null
            2 -> if (path.endsWith(".mp4", true)) "video/mp4" else null
            else -> "*/*"
        }
        if (mime == null) {
            status.text = "Ese formato requiere un enlace directo al archivo correspondiente. Esta versión no convierte audio."
            return
        }
        try {
            val request = DownloadManager.Request(uri)
                .setTitle(path)
                .setDescription("Descargando con Alejo Music Downloader")
                .setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
                .setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, "AlejoMusic/$path")
                .setAllowedOverMetered(true)
                .setAllowedOverRoaming(true)
            val manager = getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager
            manager.enqueue(request)
            status.text = "Descarga enviada. Revisa la notificación y la carpeta Descargas/AlejoMusic."
        } catch (e: Exception) {
            status.text = "No se pudo iniciar la descarga: ${e.localizedMessage ?: "error"}"
        }
    }

    private fun label(value: String): TextView = TextView(this).apply {
        text = value
        textSize = 13f
        setTextColor(Color.WHITE)
        setPadding(0, dp(8), 0, dp(8))
    }

    private fun rounded(color: Int, radius: Int): GradientDrawable =
        GradientDrawable().apply { setColor(color); cornerRadius = dp(radius).toFloat() }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()
}
