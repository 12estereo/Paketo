# SLR PRO CAMERA

Primera versión Android de cámara fotográfica con CameraX.

## Incluye
- Vista previa de cámara trasera/frontal.
- Captura priorizando calidad y JPEG al 100%.
- Zoom con botones y gesto de pinza (según capacidades del dispositivo).
- Enfoque tocando la vista previa.
- Flash/linterna.
- Compensación de exposición cuando el dispositivo la admite.
- Cuadrícula de composición.
- Filtros aplicados a la fotografía guardada: Original, Golden, Cinema, Vintage, Teal, B&W y Vivid.
- Guarda las fotos en `Pictures/SLR Pro Camera`.

## Compilar
Abre el proyecto en Android Studio y deja que Gradle sincronice. Requiere Android SDK 35 y JDK 17.

## Limitaciones honestas
CameraX y el hardware determinan qué controles están disponibles. ISO manual, velocidad de obturación y RAW no están expuestos en esta primera versión; se añadirán en una siguiente iteración tras comprobar las capacidades reales del sensor del teléfono.
