package com.slrpro.camera

import android.Manifest
import android.content.ContentValues
import android.content.pm.PackageManager
import android.graphics.*
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import android.view.*
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.camera.core.*
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.Locale
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors
import kotlin.math.max
import kotlin.math.min

class MainActivity : AppCompatActivity() {
    private lateinit var previewView: PreviewView
    private lateinit var cameraExecutor: ExecutorService
    private var imageCapture: ImageCapture? = null
    private var camera: Camera? = null
    private var lensFacing = CameraSelector.LENS_FACING_BACK
    private var currentFilter = 0
    private var flashOn = false
    private var zoomRatio = 1f
    private var exposureIndex = 0
    private val filters = arrayOf("ORIGINAL", "GOLDEN", "CINEMA", "VINTAGE", "TEAL", "B&W", "VIVID")
    private lateinit var filterLabel: TextView
    private lateinit var zoomLabel: TextView
    private lateinit var statusLabel: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        cameraExecutor = Executors.newSingleThreadExecutor()
        buildInterface()
        if (hasPermissions()) startCamera() else ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.CAMERA), 10)
    }

    private fun hasPermissions() = ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED

    private fun buildInterface() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.rgb(14, 15, 18))
        }
        val header = LinearLayout(this).apply {
            gravity = Gravity.CENTER_VERTICAL
            setPadding(18, 12, 18, 12)
            setBackgroundColor(Color.rgb(20, 21, 25))
        }
        val title = TextView(this).apply {
            text = "SLR PRO  •  CAMERA"
            textSize = 18f
            setTextColor(Color.WHITE)
            typeface = Typeface.create("sans-serif", Typeface.BOLD)
        }
        statusLabel = TextView(this).apply {
            text = "  FULL SENSOR"
            textSize = 10f
            setTextColor(Color.rgb(235, 184, 75))
        }
        header.addView(title, LinearLayout.LayoutParams(0, -2, 1f))
        header.addView(statusLabel)
        root.addView(header)

        val frame = FrameLayout(this).apply { setBackgroundColor(Color.BLACK) }
        previewView = PreviewView(this).apply {
            implementationMode = PreviewView.ImplementationMode.COMPATIBLE
            scaleType = PreviewView.ScaleType.FILL_CENTER
        }
        frame.addView(previewView, FrameLayout.LayoutParams(-1, -1))
        frame.addView(GridOverlay(this), FrameLayout.LayoutParams(-1, -1))
        val hint = TextView(this).apply {
            text = "TOCA PARA ENFOCAR  •  PINZA PARA ZOOM"
            textSize = 10f
            letterSpacing = .08f
            setTextColor(Color.WHITE)
            setPadding(12, 8, 12, 8)
            setBackgroundColor(0x55000000)
        }
        val hintParams = FrameLayout.LayoutParams(-2, -2, Gravity.TOP or Gravity.CENTER_HORIZONTAL)
        hintParams.topMargin = 14
        frame.addView(hint, hintParams)
        root.addView(frame, LinearLayout.LayoutParams(-1, 0, 1f))

        val controls = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(14, 10, 14, 12)
            setBackgroundColor(Color.rgb(20, 21, 25))
        }
        filterLabel = TextView(this).apply {
            text = "FILTRO  •  ORIGINAL"
            textSize = 12f
            setTextColor(Color.rgb(235, 184, 75))
            gravity = Gravity.CENTER
        }
        controls.addView(filterLabel)
        val filterRow = LinearLayout(this).apply { gravity = Gravity.CENTER; setPadding(0, 8, 0, 8) }
        val prev = smallButton("‹") { changeFilter(-1) }
        val next = smallButton("›") { changeFilter(1) }
        filterRow.addView(prev)
        filterRow.addView(TextView(this).apply {
            text = "  DESLIZA LOS FILTROS  "
            textSize = 10f
            setTextColor(Color.LTGRAY)
            gravity = Gravity.CENTER
        }, LinearLayout.LayoutParams(0, -2, 1f))
        filterRow.addView(next)
        controls.addView(filterRow)

        val zoomRow = LinearLayout(this).apply { gravity = Gravity.CENTER; setPadding(0, 3, 0, 8) }
        zoomLabel = TextView(this).apply { text = "ZOOM  1.0×"; setTextColor(Color.WHITE); textSize = 12f }
        zoomRow.addView(smallButton("−") { setZoom(zoomRatio / 1.25f) })
        zoomRow.addView(zoomLabel, LinearLayout.LayoutParams(0, -2, 1f))
        zoomRow.addView(smallButton("+") { setZoom(zoomRatio * 1.25f) })
        controls.addView(zoomRow)

        val actionRow = LinearLayout(this).apply { gravity = Gravity.CENTER; setPadding(0, 4, 0, 2) }
        actionRow.addView(smallButton("⚡") { toggleFlash() })
        actionRow.addView(smallButton("ISO / EV") { cycleExposure() })
        val shutter = TextView(this).apply {
            text = "●"
            textSize = 42f
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
            setOnClickListener { takePhoto() }
            setPadding(18, 0, 18, 0)
        }
        actionRow.addView(shutter)
        actionRow.addView(smallButton("↻") { switchCamera() })
        actionRow.addView(smallButton("GALERÍA") { openGallery() })
        controls.addView(actionRow)
        root.addView(controls)
        setContentView(root)

        var scale = 1f
        previewView.setOnTouchListener { _, event ->
            when (event.actionMasked) {
                MotionEvent.ACTION_POINTER_DOWN -> { scale = 1f; true }
                MotionEvent.ACTION_MOVE -> if (event.pointerCount >= 2) {
                    val dx = event.getX(0) - event.getX(1)
                    val dy = event.getY(0) - event.getY(1)
                    val distance = kotlin.math.sqrt(dx * dx + dy * dy)
                    if (scale != 1f) setZoom(zoomRatio * (distance / scale))
                    scale = distance
                    true
                } else false
                MotionEvent.ACTION_UP -> {
                    val point = previewView.meteringPointFactory.createPoint(event.x, event.y)
                    val action = FocusMeteringAction.Builder(point).setAutoCancelDuration(3, java.util.concurrent.TimeUnit.SECONDS).build()
                    camera?.cameraControl?.startFocusAndMetering(action)
                    true
                }
                else -> true
            }
        }
    }

    private fun smallButton(label: String, action: () -> Unit) = TextView(this).apply {
        text = label
        textSize = 13f
        gravity = Gravity.CENTER
        setTextColor(Color.WHITE)
        setPadding(12, 12, 12, 12)
        setOnClickListener { action() }
    }

    private fun startCamera() {
        val future = ProcessCameraProvider.getInstance(this)
        future.addListener({
            val provider = future.get()
            val preview = Preview.Builder().build().also { it.setSurfaceProvider(previewView.surfaceProvider) }
            imageCapture = ImageCapture.Builder()
                .setCaptureMode(ImageCapture.CAPTURE_MODE_MAXIMIZE_QUALITY)
                .setJpegQuality(100)
                .build()
            try {
                provider.unbindAll()
                val selector = CameraSelector.Builder().requireLensFacing(lensFacing).build()
                camera = provider.bindToLifecycle(this, selector, preview, imageCapture)
                statusLabel.text = "  MÁXIMA CALIDAD DISPONIBLE"
                val zoom = camera?.cameraInfo?.zoomState?.value
                if (zoom != null) zoomLabel.text = "ZOOM  ${"%.1f".format(zoomRatio)}×"
            } catch (e: Exception) {
                statusLabel.text = "CÁMARA NO DISPONIBLE"
                Toast.makeText(this, "No se pudo iniciar la cámara: ${e.localizedMessage}", Toast.LENGTH_LONG).show()
            }
        }, ContextCompat.getMainExecutor(this))
    }

    private fun setZoom(value: Float) {
        val state = camera?.cameraInfo?.zoomState?.value ?: return
        zoomRatio = value.coerceIn(state.minZoomRatio, state.maxZoomRatio)
        camera?.cameraControl?.setZoomRatio(zoomRatio)
        zoomLabel.text = "ZOOM  ${"%.1f".format(zoomRatio)}×"
    }

    private fun changeFilter(delta: Int) {
        currentFilter = (currentFilter + delta + filters.size) % filters.size
        filterLabel.text = "FILTRO  •  ${filters[currentFilter]}"
    }

    private fun toggleFlash() {
        flashOn = !flashOn
        camera?.cameraControl?.enableTorch(flashOn)
        Toast.makeText(this, if (flashOn) "Flash encendido" else "Flash apagado", Toast.LENGTH_SHORT).show()
    }

    private fun cycleExposure() {
        val info = camera?.cameraInfo ?: return
        val range = info.exposureState.exposureCompensationRange
        if (range.isEmpty) {
            Toast.makeText(this, "Control de exposición no disponible", Toast.LENGTH_SHORT).show()
            return
        }
        exposureIndex += 1
        if (exposureIndex > range.upper) exposureIndex = range.lower
        camera?.cameraControl?.setExposureCompensationIndex(exposureIndex)
        Toast.makeText(this, "Exposición: $exposureIndex EV", Toast.LENGTH_SHORT).show()
    }

    private fun switchCamera() {
        lensFacing = if (lensFacing == CameraSelector.LENS_FACING_BACK) CameraSelector.LENS_FACING_FRONT else CameraSelector.LENS_FACING_BACK
        startCamera()
    }

    private fun takePhoto() {
        val capture = imageCapture ?: return
        val temp = File(cacheDir, "capture_${System.currentTimeMillis()}.jpg")
        val options = ImageCapture.OutputFileOptions.Builder(temp).build()
        capture.takePicture(options, cameraExecutor, object : ImageCapture.OnImageSavedCallback {
            override fun onError(exception: ImageCaptureException) {
                runOnUiThread { Toast.makeText(this@MainActivity, "Error al tomar foto: ${exception.message}", Toast.LENGTH_LONG).show() }
            }
            override fun onImageSaved(output: ImageCapture.OutputFileResults) {
                try {
                    val original = BitmapFactory.decodeFile(temp.absolutePath)
                    val processed = applyFilter(original, currentFilter)
                    val name = "SLR_${SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(java.util.Date())}.jpg"
                    val values = ContentValues().apply {
                        put(MediaStore.Images.Media.DISPLAY_NAME, name)
                        put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg")
                        if (Build.VERSION.SDK_INT >= 29) put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/SLR Pro Camera")
                    }
                    val uri = contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values)
                    if (uri != null) contentResolver.openOutputStream(uri)?.use { processed.compress(Bitmap.CompressFormat.JPEG, 98, it) }
                    original.recycle()
                    if (processed !== original) processed.recycle()
                    temp.delete()
                    runOnUiThread { Toast.makeText(this@MainActivity, "Foto guardada en Pictures/SLR Pro Camera", Toast.LENGTH_LONG).show() }
                } catch (e: Exception) {
                    runOnUiThread { Toast.makeText(this@MainActivity, "No se pudo procesar la foto", Toast.LENGTH_LONG).show() }
                }
            }
        })
    }

    private fun applyFilter(src: Bitmap, filter: Int): Bitmap {
        if (filter == 0) return src
        val matrix = when (filter) {
            1 -> ColorMatrix(floatArrayOf(1.08f,0f,0f,0f,8f, 0f,1.02f,0f,0f,5f, 0f,0f,0.88f,0f,-3f, 0f,0f,0f,1f,0f))
            2 -> ColorMatrix(floatArrayOf(1.12f,0f,0f,0f,2f, 0f,0.96f,0f,0f,0f, 0f,0f,0.92f,0f,4f, 0f,0f,0f,1f,0f))
            3 -> ColorMatrix(floatArrayOf(0.92f,0f,0f,0f,12f, 0f,0.88f,0f,0f,8f, 0f,0f,0.78f,0f,0f, 0f,0f,0f,1f,0f))
            4 -> ColorMatrix(floatArrayOf(0.92f,0.08f,0f,0f,0f, 0f,0.98f,0.05f,0f,2f, 0.05f,0.08f,1.08f,0f,4f, 0f,0f,0f,1f,0f))
            5 -> ColorMatrix().apply { setSaturation(0f) }
            else -> ColorMatrix(floatArrayOf(1.18f,0f,0f,0f,0f, 0f,1.18f,0f,0f,0f, 0f,0f,1.18f,0f,0f, 0f,0f,0f,1f,0f))
        }
        val output = Bitmap.createBitmap(src.width, src.height, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(output)
        val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply { colorFilter = ColorMatrixColorFilter(matrix) }
        canvas.drawBitmap(src, 0f, 0f, paint)
        return output
    }

    private fun openGallery() {
        val intent = android.content.Intent(android.content.Intent.ACTION_VIEW).apply {
            setDataAndType(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, "image/*")
            addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        try { startActivity(intent) } catch (_: Exception) { Toast.makeText(this, "No se encontró una galería", Toast.LENGTH_SHORT).show() }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 10 && grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) startCamera()
        else Toast.makeText(this, "Se necesita permiso de cámara para usar SLR PRO", Toast.LENGTH_LONG).show()
    }

    override fun onDestroy() {
        super.onDestroy()
        if (::cameraExecutor.isInitialized) cameraExecutor.shutdown()
    }

    private class GridOverlay(context: android.content.Context) : View(context) {
        private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = 0x66FFFFFF
            strokeWidth = 1f
            style = Paint.Style.STROKE
        }
        override fun onDraw(canvas: Canvas) {
            super.onDraw(canvas)
            val w = width.toFloat(); val h = height.toFloat()
            canvas.drawLine(w/3, 0f, w/3, h, paint)
            canvas.drawLine(2*w/3, 0f, 2*w/3, h, paint)
            canvas.drawLine(0f, h/3, w, h/3, paint)
            canvas.drawLine(0f, 2*h/3, w, 2*h/3, paint)
        }
    }
}
