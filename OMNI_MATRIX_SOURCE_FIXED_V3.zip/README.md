# OMNI MATRIX Android

Version 1.2. Package, namespace and Kotlin MainActivity package are aligned as `com.alejo.omnimatrix360` to prevent launcher activity resolution failures.

Build with Java 17 and Gradle 8.9:

```bash
gradle assembleDebug
```

APK: `app/build/outputs/apk/debug/app-debug.apk`
